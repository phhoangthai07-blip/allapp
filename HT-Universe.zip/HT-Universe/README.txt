HT UNIVERSE
===========

This folder contains a unified web-app shell and the five existing standalone apps.

FILES
- index.html              Main HT Universe dashboard + shared Liquid Glass taskbar
- apps/deht.html          DeHT 1.6.0
- apps/ht-chat.html       HT Chat 4.6.1
- apps/ht-chess.html      HT Chess v2.2 audiofix
- apps/xiaomi-fund.html   Quỹ Xiaomi savings tracker
- apps/daily-streak.html  Daily Streak

RUN LOCALLY
For best compatibility, serve this folder through a local web server (not file://).
For example, with Python installed, open a terminal in this folder and run:
  python -m http.server 8000
Then open http://localhost:8000

PUBLISH WITH GITHUB PAGES
1. Upload the contents of this folder (index.html, README.txt, and apps/) to the root of a GitHub repository.
2. In Settings > Pages, select the branch and root folder.
3. Open the published Pages URL.

IMPORTANT NOTES
- Each legacy app is kept as a separate page inside an iframe. This isolates its CSS/JavaScript so the apps are less likely to break one another, while keeping their original features.
- Because the pages are served from the same site origin, browser localStorage remains available to each app. Existing saved data should remain available when the same browser/profile and site origin are used. Different old URLs/origins may have separate browser storage; export/backup important data before switching.
- HT Chat needs internet access and its configured Supabase service. Do not publish private service-role keys. The included source uses a publishable client key.
- DeHT 1.6.0 source currently contains placeholder Supabase URL/key values. Its account login/signup will not work until those are configured with the project's public URL and publishable key. Offline/local learning features can still be used.
- HT Chess loads chess.js from a CDN, so internet access is required for the chess rules engine. Audio requires a user interaction first because browsers restrict autoplay.
- The wrapper does not rewrite the internal business logic of the legacy apps. It provides unified navigation and visual shell; each module remains responsible for its own features and data.
- Test account sign-in, chat, and storage after publishing. No web app can be guaranteed bug-free across every browser/device without runtime testing against the actual backend and user accounts.
